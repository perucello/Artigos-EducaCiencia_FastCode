package IDE;

public class ObjetoIDE {

    private String nome; //criado nosso atributo ou caracteristica do Objeto - neste caso chamado NOME
    public String fabricante; //criado nosso atributo ou caracteristica do Objeto - neste caso chamado FABRICANTE 
    
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getFabricante() {
        return fabricante;
    }

    public void setFabricante(String fabricante) {
        this.fabricante = fabricante;
    }       
}
