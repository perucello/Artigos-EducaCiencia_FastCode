package Main;

import Funcionario.ObjetoFuncionario;
import IDE.ObjetoIDE;
import Setor.ObjetoSetor;

    public class MetodoMain {
    public static void main(String[] args) {
    
    ObjetoIDE ide = new ObjetoIDE(); 
    ide.setNome("VSCode"); 
    ide.setFabricante("Micrisoft"); 
    
    ObjetoIDE ide1 = new ObjetoIDE(); 
    ide1.setNome("Netbeans 11"); 
    ide1.setFabricante("SunMicrosystens"); 
    
    ObjetoFuncionario func = new ObjetoFuncionario();
    func.setNome("Fulano de Tal");
    func.setTecnologia("Java");

    ObjetoSetor setor = new ObjetoSetor();
    setor.setFuncao("FullStack");
    
    System.out.println("------------------------------------");
    System.out.println("O Funcionario " + func.getNome() + " " + "trabalha com a Tecnologia " + func.getTecnologia());
    System.out.println("Utiliza da IDE " + ide.getNome() + " e seu fabricante é " + ide.getFabricante());
    System.out.println("O Funcionario " + func.getNome() + " nao trabalha com a IDE " + ide1.getNome());
    System.out.println("Funcionario " + func.getNome() + " tem como função na empresa " + setor.getFuncao());
    }
}

