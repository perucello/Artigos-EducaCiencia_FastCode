insert into cliente (id, nome, email) values (null, 'Fulano de Tal', 'Fulano@Fulano.com.br');
insert into cliente (id, nome, email) values (null, 'Beltrano da Silva', 'Beltrano@Beltrano.com.br');
insert into cliente (id, nome, email) values (null, 'Ciclano Souza', 'Ciclano@Ciclano.com.br');
