create database educaciencia;
use educaciencia;
create table Usuario(
	Id integer(11) not null AUTO_INCREMENT,
    Nome varchar(30) not null,
    Cidade varchar(30) not null,
	Profissao varchar(30) not null,
    primary key (Id));

select * from usuario;
