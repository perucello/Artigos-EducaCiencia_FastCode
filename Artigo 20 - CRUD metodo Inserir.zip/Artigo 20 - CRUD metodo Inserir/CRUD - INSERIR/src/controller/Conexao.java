package controller;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;
//Classe Conexão
public class Conexao {
//Detalhes da Conexão    
    private static final String DATABASE="clinica"; // Nome do Banco de Dados
    private static final String HOST="jdbc:mysql://localhost:3306/clinica"; //Host
    private static final String DRIVER="com.mysql.jdbc.Driver"; //Driver
    private static final String URL="jdbc:mysql://localhost:3306/clinica?useTimezone=true&serverTimezone=UTC&useSSL=false"; //Para tirar erro de SSL em alguns casos em que tem varios Bancos e Certificados
    private static final String USR="root"; //Nome do usuario de acesso ao Banco de Dados
    private static final String PWD=""; // senha definida no Banco de Dados
    
//Metodo conectar    
    public static Connection Conectar(){
        try{
            Class.forName(DRIVER);
            return DriverManager.getConnection(URL, USR, PWD);
        } 
        catch (ClassNotFoundException | SQLException e) {
            System.out.println("ERRO: " + e.getMessage());
            JOptionPane.showMessageDialog(null, "Falha de comunicação com BD", "ERROR", JOptionPane.WARNING_MESSAGE);
            return null;
        }
    }
//Método Desconectar    
    public static void Desconectar (Connection con){
        try{
            if (con != null){
                con.close();
            }
        }
        catch (SQLException e){
                System.out.println("ERRO: " + e.getMessage());
                }
        }  
//PARA TESTAR VIA SCRIPT    
//Metodo Main 
    public static void main(String[] args){
        if (Conectar() != null){
            System.out.println("Conexão realizada com sucesso!");
        }
    }
}




