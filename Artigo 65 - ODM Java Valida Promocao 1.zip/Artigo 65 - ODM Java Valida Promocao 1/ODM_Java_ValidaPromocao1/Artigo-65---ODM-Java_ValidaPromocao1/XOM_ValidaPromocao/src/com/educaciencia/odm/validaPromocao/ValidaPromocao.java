package com.educaciencia.odm.validaPromocao;

public class ValidaPromocao {

	private boolean validaPromocao;

	public ValidaPromocao() {
		super();
	}

	public ValidaPromocao(boolean validaPromocao) {
		super();
		this.validaPromocao = validaPromocao;
	}

	public boolean isValidaPromocao() {
		return validaPromocao;
	}

	public void setValidaPromocao(boolean validaPromocao) {
		this.validaPromocao = validaPromocao;
	}

}
