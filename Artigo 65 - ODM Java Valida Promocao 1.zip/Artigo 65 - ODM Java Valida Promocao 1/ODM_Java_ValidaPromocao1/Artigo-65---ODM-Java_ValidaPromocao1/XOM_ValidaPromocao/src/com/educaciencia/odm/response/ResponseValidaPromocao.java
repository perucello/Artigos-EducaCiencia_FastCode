package com.educaciencia.odm.response;

public class ResponseValidaPromocao {

	private String valorProduto;

	public ResponseValidaPromocao() {
		super();
	}

	public ResponseValidaPromocao(String valorProduto) {
		super();
		this.valorProduto = valorProduto;
	}

	public String getValorProduto() {
		return valorProduto;
	}

	public void setValorProduto(String valorProduto) {
		this.valorProduto = valorProduto;
	}

}
