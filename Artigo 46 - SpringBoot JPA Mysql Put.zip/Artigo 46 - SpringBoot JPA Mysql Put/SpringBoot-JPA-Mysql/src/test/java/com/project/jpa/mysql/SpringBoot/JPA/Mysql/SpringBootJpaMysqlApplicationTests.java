package com.project.jpa.mysql.SpringBoot.JPA.Mysql;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootJpaMysqlApplicationTests {

	@Test
	void contextLoads() {
	}

}
