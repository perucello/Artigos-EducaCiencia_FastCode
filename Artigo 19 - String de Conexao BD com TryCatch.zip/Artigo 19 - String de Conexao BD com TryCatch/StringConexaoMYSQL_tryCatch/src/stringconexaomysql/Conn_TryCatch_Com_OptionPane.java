package stringconexaomysql;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class Conn_TryCatch_Com_OptionPane {
    private static final String DATABASE="clinica";
    private static final String HOST="jdbc:mysql://localhost:3306/clinica";
    private static final String DRIVER="com.mysql.jdbc.Driver";
    //Para tirar erro de SSL em alguns casos em que tem varios Bancos e Certificados
    private static final String URL="jdbc:mysql://localhost:3306/clinica?useTimezone=true&serverTimezone=UTC&useSSL=false";
    private static final String USR="root";
    private static final String PWD="";
   
    public static Connection Conectar(){
        try{
            Class.forName(DRIVER);
            return DriverManager.getConnection(URL, USR, PWD);
        } 
        catch (ClassNotFoundException | SQLException e) {
            JOptionPane.showMessageDialog(null,"Falha de Comunicação com Banco de Dados", "Conexão com Banco", JOptionPane.WARNING_MESSAGE);
            return null;
        }
    }
    public static void main(String[] args){
        if (Conectar() != null){
              JOptionPane.showMessageDialog(null,"Banco de Dados conectado !", "Conexão com Banco de Dados Clinica", JOptionPane.INFORMATION_MESSAGE);
        }
    }
}