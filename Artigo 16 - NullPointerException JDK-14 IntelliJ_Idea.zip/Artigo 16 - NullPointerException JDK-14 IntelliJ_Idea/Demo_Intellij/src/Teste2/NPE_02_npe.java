package Teste2;
public class NPE_02_npe {
    //declarando a variavel teste sem argumentos
    String teste;
    //declarando a variavel test1 e definindo como "teste1"
    String teste1 = "teste1";
    //declarando a variavel teste2 e definindo como 1
    int teste2 = 1;

    public static void main(String[] args) {
        NPE_02_npe npe = new NPE_02_npe();
        // neste momento deve estourar NPE porem com o java 14 retornara que o npe.teste é nullo
        System.out.println("Estourando npe => " + npe.teste.toUpperCase()); //nesse momento estoura NullPointer, pois o Objeto nao foi informado!

        //passando os souts para trazer retorno das demais variaveis
        System.out.println("retornando teste => " + npe.teste);
        System.out.println("trazendo valor de teste1 => " + npe.teste1.toUpperCase());
        System.out.println("trazendo valor de teste2 => " + npe.teste2);
    }
}