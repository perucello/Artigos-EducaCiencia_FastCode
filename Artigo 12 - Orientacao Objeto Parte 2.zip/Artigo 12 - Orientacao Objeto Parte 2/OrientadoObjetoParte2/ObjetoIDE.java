//criado nossa Classe - Objeto - no caso chamado ObjetoIDE
public class ObjetoIDE{

    String nome; //criado nosso atributo ou caracteristica do Objeto - neste caso chamado NOME
    String fabricante; //criado nosso atributo ou caracteristica do Objeto - neste caso chamado FABRICANTE
    
    //Criando nosso método Status onde manipularemos um SOUT para trazer de retorno na tela - instanciado na classe MetodoMain.java
    void Status(){
        //Neste momento vamos imprimir na tela o NOME e FABRICANTE que passaremos por argumento, neste caso referenciando pelo THIS
        System.out.println("Você escolheu a IDE " + this.nome + " para trabalhar no desenolvimento JAVA !");
        System.out.println("O Fabricante : " + this.fabricante);
        //estamos condicionando a escolha do fabricante sendo Microsoft
        if (fabricante == "Microsoft") {
            System.out.println("o VSCode é o queridinho do Desenvolvedor !!!");
        }if (fabricante == "Netbeans"){
            //estamos trazendo um comentario em caso de termos escolhido NetBeans
            System.out.println("Você escolheu Netbeans, uma IDE muito completa para javaFX !");         
        } else {
            System.out.println(" ");
        }
    }
}