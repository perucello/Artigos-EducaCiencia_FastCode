public class MetodoMain{

 public static void main(String[] args) {
  /*   
    //Estamos criando um novo objeto e populando as suas caracteristicas/atributos
    ObjetoIDE ide = new ObjetoIDE();
    ide.nome = "VSCode";
    ide.fabricante = "Microsoft";
    ide.Status();
    
    //Estamos criando um novo objeto e populando as suas caracteristicas/atributos
    ObjetoIDE ide1 = new ObjetoIDE();
    ide1.nome = "Netbeans 11";
    ide1.fabricante = "SunMicrosystens";
    ide1.Status();
*/
    ObjetoIDE ide2 = new ObjetoIDE();
    ide2.nome = "IntelliJ IDEA";
    ide2.fabricante = "JetBrains";
    ide2.Status();
    
    }
}