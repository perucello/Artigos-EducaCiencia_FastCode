package com.project.jpa.JavaJPA;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavaJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
