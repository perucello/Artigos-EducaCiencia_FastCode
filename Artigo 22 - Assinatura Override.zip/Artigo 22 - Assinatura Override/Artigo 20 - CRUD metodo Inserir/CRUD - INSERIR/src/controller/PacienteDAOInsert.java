package controller;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import model.PacienteInsert;
//Classe PacienteDAOInsert
public class PacienteDAOInsert {
    //Abrindo nossa conexão com Banco de Dados
    private final Connection con;
    private PreparedStatement cmd;
    //Método para abrir nossa Conexão 
    public PacienteDAOInsert(){
        this.con = Conexao.Conectar();
    }
//Criando nosso Método para Inserir - insert do Banco de Dados         
    public int inserir(PacienteInsert p){
           try{
            String sql = "insert into paciente (nome, peso, altura) values (?, ?, ?);";
            cmd = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            cmd.setString(1, p.getNome());
            cmd.setFloat(2, p.getPeso());
            cmd.setFloat(3, p.getAltura());
                        if (cmd.executeUpdate() > 0){
                            ResultSet rs = cmd.getGeneratedKeys();
                            return (rs.next()) ? rs.getInt(1): -1;
                        }else{
                            return -1;
                        }
        }        
        catch (SQLException e){
            System.out.println("ERRO SQL: " + e.getMessage());
            return -1;
        }  
        finally{
            Conexao.Desconectar(con);
        }     
    }
}
