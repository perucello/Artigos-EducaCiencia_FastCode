
package view;

import controller.PacienteDAOInsert;
import javax.swing.JOptionPane;
import model.PacienteInsert;

public class NewMDIApplicationTAREFA extends javax.swing.JFrame {

     public NewMDIApplicationTAREFA() {
        initComponents();
        //Passo 4 - vamos adicionar nosso Configurarformulario na inicialização.
        configurarformulario();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        desktopPane = new javax.swing.JDesktopPane();
        jLabelTITULO = new javax.swing.JLabel();
        jLabelID = new javax.swing.JLabel();
        jLabel3NOME = new javax.swing.JLabel();
        jLabelPESO = new javax.swing.JLabel();
        jLabelALTURA = new javax.swing.JLabel();
        jTextid = new javax.swing.JTextField();
        jTextNOME = new javax.swing.JTextField();
        jTextPESO = new javax.swing.JTextField();
        jTextALTURA = new javax.swing.JTextField();
        jButtonNOVO = new javax.swing.JButton();
        jButtonSALVAR = new javax.swing.JButton();
        jButtonCANCELAR = new javax.swing.JButton();
        jButtonSAIR = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabelTITULO.setFont(new java.awt.Font("Trebuchet MS", 3, 18)); // NOI18N
        jLabelTITULO.setText("Projeto Paciente");
        desktopPane.add(jLabelTITULO);
        jLabelTITULO.setBounds(110, 30, 170, 40);

        jLabelID.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabelID.setText("Id");
        desktopPane.add(jLabelID);
        jLabelID.setBounds(80, 100, 31, 22);

        jLabel3NOME.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel3NOME.setText("Nome");
        desktopPane.add(jLabel3NOME);
        jLabel3NOME.setBounds(70, 140, 46, 30);

        jLabelPESO.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabelPESO.setText("Peso");
        desktopPane.add(jLabelPESO);
        jLabelPESO.setBounds(70, 190, 40, 20);

        jLabelALTURA.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabelALTURA.setText("Altura");
        desktopPane.add(jLabelALTURA);
        jLabelALTURA.setBounds(60, 240, 50, 20);

        jTextid.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jTextid.setText("jTextField1");
        desktopPane.add(jTextid);
        jTextid.setBounds(120, 79, 180, 40);

        jTextNOME.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jTextNOME.setText("jTextField2");
        desktopPane.add(jTextNOME);
        jTextNOME.setBounds(120, 130, 180, 40);

        jTextPESO.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jTextPESO.setText("jTextField3");
        desktopPane.add(jTextPESO);
        jTextPESO.setBounds(120, 180, 180, 40);

        jTextALTURA.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jTextALTURA.setText("jTextField4");
        desktopPane.add(jTextALTURA);
        jTextALTURA.setBounds(120, 229, 180, 40);

        jButtonNOVO.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jButtonNOVO.setText("novo");
        jButtonNOVO.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonNOVOActionPerformed(evt);
            }
        });
        desktopPane.add(jButtonNOVO);
        jButtonNOVO.setBounds(30, 280, 90, 40);

        jButtonSALVAR.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jButtonSALVAR.setText("salvar");
        jButtonSALVAR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonSALVARActionPerformed(evt);
            }
        });
        desktopPane.add(jButtonSALVAR);
        jButtonSALVAR.setBounds(140, 280, 90, 40);

        jButtonCANCELAR.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jButtonCANCELAR.setText("cancelar");
        jButtonCANCELAR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonCANCELARActionPerformed(evt);
            }
        });
        desktopPane.add(jButtonCANCELAR);
        jButtonCANCELAR.setBounds(240, 280, 110, 40);

        jButtonSAIR.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jButtonSAIR.setText("sair");
        jButtonSAIR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonSAIRActionPerformed(evt);
            }
        });
        desktopPane.add(jButtonSAIR);
        jButtonSAIR.setBounds(280, 330, 90, 40);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(desktopPane, javax.swing.GroupLayout.DEFAULT_SIZE, 380, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(desktopPane, javax.swing.GroupLayout.DEFAULT_SIZE, 381, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButtonSAIRActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonSAIRActionPerformed
        dispose();
    }//GEN-LAST:event_jButtonSAIRActionPerformed

    private void jButtonNOVOActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonNOVOActionPerformed
        estadocontrole(false);
        limpar();
        
    }//GEN-LAST:event_jButtonNOVOActionPerformed

    private void jButtonCANCELARActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonCANCELARActionPerformed
    estadocontrole(true);
    limpar();
    }//GEN-LAST:event_jButtonCANCELARActionPerformed

    private void jButtonSALVARActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonSALVARActionPerformed
        PacienteInsert p = new PacienteInsert();
            if (!jTextid.getText().isEmpty()) {
                p.setId(Integer.parseInt(jTextid.getText()));
            }
            p.setNome(jTextNOME.getText());
            p.setPeso(Float.parseFloat(jTextPESO.getText()));
            p.setAltura(Float.parseFloat(jTextALTURA.getText()));

            int res = -1;

            if (p.getId() == 0) {
                res = new PacienteDAOInsert().inserir(p);
                jTextid.setText((Integer.toString(res)));
            }
            if (res != -1) {
                JOptionPane.showMessageDialog(null, "Operação OK !", "Inserir Paciente CRUD", JOptionPane.INFORMATION_MESSAGE);
            }else{
                JOptionPane.showMessageDialog(null, "Algo deu errado!", "ERROR", JOptionPane.WARNING_MESSAGE);
            }

            estadocontrole(true);

    }//GEN-LAST:event_jButtonSALVARActionPerformed


    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(NewMDIApplicationTAREFA.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(NewMDIApplicationTAREFA.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(NewMDIApplicationTAREFA.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(NewMDIApplicationTAREFA.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new NewMDIApplicationTAREFA().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JDesktopPane desktopPane;
    private javax.swing.JButton jButtonCANCELAR;
    private javax.swing.JButton jButtonNOVO;
    private javax.swing.JButton jButtonSAIR;
    private javax.swing.JButton jButtonSALVAR;
    private javax.swing.JLabel jLabel3NOME;
    private javax.swing.JLabel jLabelALTURA;
    private javax.swing.JLabel jLabelID;
    private javax.swing.JLabel jLabelPESO;
    private javax.swing.JLabel jLabelTITULO;
    private javax.swing.JTextField jTextALTURA;
    private javax.swing.JTextField jTextNOME;
    private javax.swing.JTextField jTextPESO;
    private javax.swing.JTextField jTextid;
    // End of variables declaration//GEN-END:variables

    //Passo 1 - criando metodo para configurar o Formulario
    private void configurarformulario(){
    this.setTitle("Java Intermediario"); //titulo
    this.setResizable(false);
    this.setLocationRelativeTo(null);
    estadocontrole(true); //estado controle adicionado somente depois que criarmos o Metodo estadocontrole
    jTextid.setEnabled(false);//nesse momento, estamos definindo que o campo jtextid nao será manipulado (desabilitado)
    }
    //Passo 2 - Criando metodo para manipularmos o estado Controle da nossa tela - mais performatico.
    private void estadocontrole(boolean e){
        jButtonNOVO.setEnabled(e); //estamos setando que nosso Botao Novo ficará Habilitado
        jButtonSALVAR.setEnabled(!e);// estamos definindo que nosso botao Salvar nao estará habilitado
        jButtonCANCELAR.setEnabled(!e);// estamos definindo que nosso botao Cancelar nao estará habilitado
        
        jTextNOME.setEnabled(!e);//Estamos definindo que o campo JTextNOME nao estará habilitado
        jTextPESO.setEnabled(!e);//Estamos definindo que o campo JTextPESO nao estará habilitado
        jTextALTURA.setEnabled(!e);//Estamos definindo que o campo JTextALTURA nao estará habilitado        
    }
    //Passo 3 - criando metodo para limpar os dados que estiverem no campo texto.
    private void limpar(){
        jTextid.setText(""); //estamos definindo que o campo textoid será limpo após ação
        jTextNOME.setText("");//estamos definindo que o campo textoNOME será limpo após ação
        jTextPESO.setText("");//estamos definindo que o campo textoPESO será limpo após ação
        jTextALTURA.setText("");//estamos definindo que o campo textoALTURA será limpo após ação
    }
    
}//Chave que fecha a classe
