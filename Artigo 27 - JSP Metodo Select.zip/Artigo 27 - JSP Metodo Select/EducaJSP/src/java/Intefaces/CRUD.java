
package Intefaces;

import Modelo.Pessoa;
import java.util.List;


public interface CRUD {
    public List listar();
    public Pessoa list(int id);
}
