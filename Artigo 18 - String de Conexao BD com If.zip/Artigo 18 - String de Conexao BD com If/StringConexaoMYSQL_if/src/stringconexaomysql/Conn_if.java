package stringconexaomysql;
//Bibliotecas Importadas - pacote java.sql
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conn_if {
    //Parametros para conexão com Banco de Dados
    private static final String URL="jdbc:mysql://localhost:3306/clinica";
    private static final String USR="root";
    private static final String PWD="";

    //Método Conectar - utilizando da Clausula IF
    public static Connection Conectar() throws SQLException {
        if (true) {
        DriverManager.registerDriver(new com.mysql.jdbc.Driver());    
        return DriverManager.getConnection(URL, USR, PWD);   
        // return (Connection) DriverManager.getConnection(URL, USR, PWD);   
        }
        return null;
     } 
    //Método Main - com clausula If
    public static void main(String[] args) throws ClassNotFoundException, SQLException{
        if (Conectar() != null) {
            System.out.println("conexão com Banco de Dados OK - driver Con_basico" );
        }
    }      
}


